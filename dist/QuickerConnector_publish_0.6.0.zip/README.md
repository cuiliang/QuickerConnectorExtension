#Quicker Chrome Connector

The Chrome Extension used to communicate with the Quicker Application
https://getquicker.net


## 0.6.0
- Show status of connection to Quicker
- Reconnect to Quicker 