#Quicker Chrome Connector

The Chrome Extension used to communicate with the Quicker Application
https://getquicker.net
